//
//  MIDUrlHandler.h
//  MidtransCoreKit
//
//  Created by Muhammad.Masykur on 01/11/18.
//  Copyright © 2018 Midtrans. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MIDUrlHandler : NSObject

+ (void)handleUrl:(NSURL *)url;

@end

NS_ASSUME_NONNULL_END
