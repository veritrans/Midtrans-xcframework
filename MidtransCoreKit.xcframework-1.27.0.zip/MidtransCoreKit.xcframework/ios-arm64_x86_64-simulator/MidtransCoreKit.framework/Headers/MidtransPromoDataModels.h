//
//  DataModels.h
//
//  Created by Ratna Kumalasari on 3/28/18
//  Copyright (c) 2018 __MyCompanyName__. All rights reserved.
//

#import "MidtransPromoPromoDetails.h"#import "MidtransPromoResponse.h"#import "MidtransPromoPromos.h"