//
//  DataModels.h
//
//  Created by Zanna Simarmata on 12/22/16
//  Copyright (c) 2016 __MyCompanyName__. All rights reserved.
//

#import "MidtransBinResponse.h"