//
//  DataModels.h
//
//  Created by Zanna Simarmata on 3/7/17
//  Copyright (c) 2017 __MyCompanyName__. All rights reserved.
//

#import "SNPPointResponse.h"
