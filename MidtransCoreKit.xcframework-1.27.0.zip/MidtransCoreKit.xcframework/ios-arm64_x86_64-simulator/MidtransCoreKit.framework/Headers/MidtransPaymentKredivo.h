//
//  MidtransPaymentKredivo.h
//  MidtransCoreKit
//
//  Created by Muhammad Masykur on 14/05/24.
//  Copyright © 2024 Midtrans. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MidtransPaymentDetails.h"

NS_ASSUME_NONNULL_BEGIN

@interface MidtransPaymentKredivo : NSObject <MidtransPaymentDetails>

@end

NS_ASSUME_NONNULL_END
